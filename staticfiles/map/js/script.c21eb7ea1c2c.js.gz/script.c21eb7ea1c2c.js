let popupAtivo = null;

// ===================== Config Mapbox =====================
const token = window.MAPBOX_PUBLIC_TOKEN || "";
if (!token) console.error("MAPBOX_PUBLIC_TOKEN não definido no template.");
mapboxgl.accessToken = token;

const map = new mapboxgl.Map({
  container: "map",
  style: "mapbox://styles/gatocangaceiro/cmbicxxq2006g01s2e0ht9l0l",
  zoom: 3.5,
  center: [-54, -15],
  preserveDrawingBuffer: true,
  crossSourceCollisions: false

});
map.addControl(new mapboxgl.NavigationControl());

const DEFAULT_VIEW = { center: [-54, -15], zoom: 3.5 };

// ===================== Filtros (refs) =====================
const filtroRegiao         = document.getElementById('filtro-regiao');
const filtroUf             = document.getElementById('filtro-uf');
const filtroMunicipio      = document.getElementById('filtro-municipio');
const filtroPorte          = document.getElementById('filtro-porte');
const filtroSubgrupo       = document.getElementById('filtro-subgrupo');
const filtroRm             = document.getElementById('filtro-rm');
const filtroClassificacao  = document.getElementById('filtro-classificacao');
const filtroModoCalculo    = document.getElementById('filtro-modo-calculo');

let debounceTimer = null;
let lastRequestId = 0;

// ===================== Helpers =====================
function restoreSelectValue(selectEl, value) {
  const has = Array.from(selectEl.options).some(o => o.value === value);
  selectEl.value = has ? value : 'todos';
}

function buildApiUrl(basePath, params) {
  const usp = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '' && v !== 'todos') usp.append(k, v);
  });
  const qs = usp.toString();
  return qs ? `${basePath}?${qs}` : basePath;
}

function paramsKeyFromSelects() {
  const raw = {
    regiao: filtroRegiao.value,
    uf: filtroUf.value,
    municipio: filtroMunicipio.value,
    porte: filtroPorte.value,
    subgrupo: filtroSubgrupo.value,
    rm: filtroRm.value,
    classification: filtroClassificacao.value,
    calculation_mode: filtroModoCalculo.value
  };
  const cleaned = {};
  Object.entries(raw).forEach(([k, v]) => { if (v && v !== 'todos') cleaned[k] = v; });
  return JSON.stringify(Object.keys(cleaned).sort().reduce((acc, k) => (acc[k] = cleaned[k], acc), {}));
}

// ===================== Filtros dependentes =====================
async function updateDependentFilters() {
  const regiaoAtual    = filtroRegiao.value;
  const ufAtual        = filtroUf.value;
  const rmAtual        = filtroRm.value;
  const municipioAtual = filtroMunicipio.value;

  /* Monta os parametros com o estado atual para o backend retornar apenas itens validos */
  const params = {
    regiao: regiaoAtual,
    uf: ufAtual,
    rm: rmAtual,
    porte: filtroPorte.value
  };

  try {
    const url = buildApiUrl('/api/get-dependent-filters/', params);
    const response = await fetch(url);
    const data = await response.json();

    filtroRegiao.innerHTML = '<option value="todos">Todas</option>';
    data.regioes.forEach(v => filtroRegiao.add(new Option(v, v)));
    restoreSelectValue(filtroRegiao, regiaoAtual);

    filtroRm.innerHTML = '<option value="todos">Todas</option>';
    data.rms.forEach(v => filtroRm.add(new Option(v, v)));
    restoreSelectValue(filtroRm, rmAtual);

    filtroUf.innerHTML = '<option value="todos">Todas</option>';
    data.ufs.forEach(v => filtroUf.add(new Option(v, v)));
    restoreSelectValue(filtroUf, ufAtual);

    filtroMunicipio.innerHTML = '<option value="todos">Todos</option>';
    data.municipios.forEach(v => filtroMunicipio.add(new Option(v, v)));
    restoreSelectValue(filtroMunicipio, municipioAtual);
  } catch (err) {
    console.error("Erro ao atualizar filtros dependentes:", err);
  }
}

// ===================== Atualização do mapa =====================
async function atualizarMapa() {
  const classificacaoAtual = filtroClassificacao.value;

  const paramsResumo = {
    regiao: filtroRegiao.value,
    uf: filtroUf.value,
    municipio: filtroMunicipio.value,
    porte: filtroPorte.value,
    subgrupo: filtroSubgrupo.value,
    rm: filtroRm.value,
    classification: classificacaoAtual,
    calculation_mode: filtroModoCalculo.value
  };

  const paramsMapa = {
    ...paramsResumo,
    municipio: 'todos' 
  };

  const desiredKey = paramsKeyFromSelects();
  const myId = ++lastRequestId;

  try {
    const [respMapa, respResumo] = await Promise.all([
      fetch(buildApiUrl('/api/dados-municipios/', paramsMapa)),
      fetch(buildApiUrl('/api/dados-municipios/', paramsResumo))
    ]);

    const geojsonMapa   = await respMapa.json();
    const geojsonResumo = await respResumo.json();

    if (myId !== lastRequestId) return;
    if (paramsKeyFromSelects() !== desiredKey) return;

    // ===== RESUMO =====
    const features = geojsonResumo.features || [];
    const count = features.length;
    const totalRevenue = features.reduce((s, f) => s + (f.properties.rc_24_pc || 0), 0);
    const averageRevenue = count > 0 ? totalRevenue / count : 0;

    document.getElementById('summary-count').textContent =
      count.toLocaleString('pt-BR');

    document.getElementById('summary-avg-revenue').textContent =
      averageRevenue.toLocaleString('pt-BR', {
        style: 'currency',
        currency: 'BRL'
      });

    // ===== MAPA (SEMPRE TODOS OS MUNICÍPIOS) =====
    if (map.getSource('municipios')) {
      map.getSource('municipios').setData(geojsonMapa);
      applyZoom(geojsonMapa); 
    }

  } catch (err) {
    console.error("Erro ao atualizar os dados do mapa ou resumo:", err);
    document.getElementById('summary-count').textContent = '0';
    document.getElementById('summary-avg-revenue').textContent = 'R$ 0,00';
  }
}


function scheduleAtualizarMapa(delay = 150) {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(atualizarMapa, delay);
}

// ===================== Mapa: load =====================
map.on("load", async () => {
  map.addSource("municipios", { type: "geojson", data: { type: "FeatureCollection", features: [] } });

  map.addLayer({
    id: "populacao-circulos",
    type: "circle",
    source: "municipios",
    paint: {
      "circle-radius": ["interpolate", ["linear"], ["get", "Populacao24"],
        100000, 7, 1000000, 14, 10000000, 28],
      "circle-opacity": 0.8,
      "circle-stroke-width": 1,
      "circle-stroke-color": "#ffffff"
    }
  });

  map.addLayer({
    id: "municipio-labels",
    type: "symbol",
    source: "municipios",
    minzoom: 7,
    layout: {
      "text-field": ["get", "name_muni"],
      "text-font": ["Open Sans Semibold", "Arial Unicode MS Bold"],
      "text-size": 11,
      "text-offset": [0, 0.9],
      "text-anchor": "top"
    },
    paint: {
      "text-color": "#2c3e50",
      "text-halo-color": "rgba(255,255,255,0.9)",
      "text-halo-width": 1.5
    }
  });

  hideBaseMunicipalityLayers();
  await updateDependentFilters();
  atualizarClassificacao(); // seta cores + legenda e chama o debounce internamente

// =========================================================
  // LOGICA UNIFICADA: Xambioá e Varginha
  // =========================================================
  const MUNI_ESPECIAIS = {
    'Xambioá - TO': { 
      coord: [-48.536, -6.415], 
      imgId: 'xambioa-badge', 
      url: '/static/map/images/xambioa.png' 
    },
    'Varginha - MG': { 
      coord: [-45.441, -21.551], 
      imgId: 'varginha-badge', 
      url: '/static/map/images/varginha.png' 
    }
  };

  // Carrega as imagens no Mapbox
  Object.entries(MUNI_ESPECIAIS).forEach(([nome, data]) => {
    map.loadImage(data.url, (err, img) => {
      if (err) return;
      if (!map.hasImage(data.imgId)) map.addImage(data.imgId, img);
    });
  });

  // Source único para o destaque
  if (!map.getSource('municipio-highlight')) {
    map.addSource('municipio-highlight', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
  }

  // Camadas de ícones no mapa
  ['xambioa-badge', 'varginha-badge'].forEach(id => {
    const layerId = `${id}-layer`;
    if (!map.getLayer(layerId)) {
      
      // Define tamanhos diferentes: Varginha começa muito menor para o efeito surpresa
      const iconSizeConfig = id === 'varginha-badge' 
        ? ['interpolate', ['linear'], ['zoom'], 5, 0.01, 8, 0.03, 10, 0.08, 12, 0.25, 14, 0.50]
        : ['interpolate', ['linear'], ['zoom'], 5, 0.08, 8, 0.12, 10, 0.16, 12, 0.22];

      map.addLayer({
        id: layerId,
        type: 'symbol',
        source: 'municipio-highlight',
        layout: { 
          'icon-image': id, 
          'icon-size': iconSizeConfig,
          'icon-allow-overlap': true, 
          'visibility': 'none',
          'icon-anchor': 'bottom' 
        },
        paint: { 'icon-translate': [0, -18] }
      });
    }
  });

  function gerenciarBadges() {
    const val = filtroMunicipio.value || '';
    const label = filtroMunicipio.selectedOptions?.[0]?.text?.trim() || '';
    const selecionado = Object.keys(MUNI_ESPECIAIS).find(k => val === k || label === k);

    const src = map.getSource('municipio-highlight');

    if (selecionado) {
      const data = MUNI_ESPECIAIS[selecionado];
      
      // Atualiza o ponto no mapa
      src.setData({ type: 'FeatureCollection', features: [{ 
        type:'Feature', geometry:{ type:'Point', coordinates: data.coord } 
      }] });

      // Alterna visibilidade das camadas
      map.setLayoutProperty('xambioa-badge-layer', 'visibility', selecionado === 'Xambioá - TO' ? 'visible' : 'none');
      map.setLayoutProperty('varginha-badge-layer', 'visibility', selecionado === 'Varginha - MG' ? 'visible' : 'none');

      // IMPORTANTE: A lógica de atualizar o Card Lateral (htmlCont) foi removida 
      // para manter o badge em segredo até o usuário dar zoom no mapa.
    } else {
      // Esconde tudo no mapa se nenhum município especial estiver selecionado
      src.setData({ type:'FeatureCollection', features:[] });
      map.setLayoutProperty('xambioa-badge-layer', 'visibility', 'none');
      map.setLayoutProperty('varginha-badge-layer', 'visibility', 'none');
    }
  }

  // Listeners para ativação
  filtroMunicipio.addEventListener('change', gerenciarBadges);
  document.getElementById('btn-limpar-filtros').addEventListener('click', () => setTimeout(gerenciarBadges, 100));

});

/* ===================== Popup de Clique no Mapa ===================== */
  map.on("click", "populacao-circulos", (e) => {
    if (e.features.length === 0) return;
    
    const feature = e.features[0];
    const coords = feature.geometry.coordinates.slice();
    
    /* Centraliza o mapa na coordenada clicada preservando o zoom atual */
    map.flyTo({ 
        center: coords,
        offset: [0, 150],
        speed: 0.8, 
        curve: 1.3 
    });
    
    abrirPopupDoMunicipioSelecionado(feature);
});

/* Gerenciamento de fechamento do popup ao clicar no vazio do mapa */
map.on("click", (e) => {
    const features = map.queryRenderedFeatures(e.point, { layers: ["populacao-circulos"] });
    if (!features.length && popupAtivo) {
        popupAtivo.remove();
        popupAtivo = null;
    }
});

/* --- LIMPAR CARD AO DAR ZOOM --- */
map.on("zoomstart", () => {
    if (popupAtivo) {
        popupAtivo.remove();
        popupAtivo = null;
        
        // Remove a etiqueta de card ativo para que as legendas reapareçam
        const mapPage = document.querySelector('.map-page');
        if (mapPage) {
            mapPage.classList.remove('popup-active');
        }
    }
});


// ===================== Zoom helpers =====================
function getGeoJSONBounds(geojson) {
  const coords = [];
  geojson.features.forEach(f => {
    const g = f.geometry; if (!g) return;
    const push = (c) => coords.push(c);
    const walk = (arr) => Array.isArray(arr[0]) ? arr.forEach(walk) : push(arr);
    walk(g.coordinates);
  });
  if (!coords.length) return null;
  let [minX, minY] = coords[0], [maxX, maxY] = coords[0];
  coords.forEach(([x,y]) => { if (x<minX)minX=x; if (x>maxX)maxX=x; if (y<minY)minY=y; if (y>maxY)maxY=y; });
  return [[minX,minY],[maxX,maxY]];
}

//====== Aplica Zoom ======

function applyZoom(geojsonData) {
  if (filtroMunicipio.value !== 'todos') {
    const f = geojsonData.features?.find(ft =>
      (ft.properties?.name_muni === filtroMunicipio.value) ||
      (ft.properties?.name_muni_uf === filtroMunicipio.value)
    );
      if (f && f.geometry) {
        if (f.geometry.type === 'Point') {
          const [lng, lat] = f.geometry.coordinates;
          map.flyTo({ center:[lng,lat], zoom:9, speed:0.8, curve:1.3 });
        } else {
          const bbox = getGeoJSONBounds({ type:'FeatureCollection', features:[f] });
          if (bbox) map.fitBounds(bbox, { padding:50, maxZoom:9, duration:700 });
        }

        // ✅ AQUI ABRE O POPUP AUTOMATICAMENTE APÓS O ZOOM
        setTimeout(() => {
          abrirPopupDoMunicipioSelecionado(f);
        }, 600);

        return;
      }

  }

  if (filtroUf.value !== 'todos' || filtroRm.value !== 'todos' ||
      filtroRegiao.value !== 'todos' || filtroPorte.value !== 'todos' ||
      filtroSubgrupo.value !== 'todos') {
    const bbox = getGeoJSONBounds(geojsonData);
    if (bbox) { map.fitBounds(bbox, { padding:50, maxZoom:7.5, duration:700 }); return; }
  }

  map.flyTo({ center: DEFAULT_VIEW.center, zoom: DEFAULT_VIEW.zoom, speed:0.8, curve:1.3 });
}


function abrirPopupDoMunicipioSelecionado(feature) {
  if (!feature?.properties) return;

  const props = feature.properties;
  const coords = feature.geometry.coordinates.slice();

  // --- CENTRALIZAÇÃO ULTRA FLUIDA (DESLIZE PURO) ---
  if (window.innerWidth < 992) {
    map.flyTo({
      center: coords,
      offset: [0, 180],
      speed: 0.4,
      curve: 0.01,
      essential: true,
      easing: (t) => t * (2 - t) 
    });
  }

  /* 1. Recupera a cor do quintil (usada na bolinha do mapa) */
  const corQuintil = map.getPaintProperty('populacao-circulos', 'circle-color');
  
  /* Logica para pegar a cor exata baseada no valor do quintil atual da feature */
  let corDaTag = '#94a3b8'; // Cor default (cinza)
  if (Array.isArray(corQuintil)) {
      // Procura a cor correspondente ao valor do dynamic_quantile no array do Mapbox
      for (let i = 2; i < corQuintil.length; i += 2) {
          if (props.dynamic_quantile === corQuintil[i]) {
              corDaTag = corQuintil[i+1];
              break;
          }
      }
  }

  const quintilValue = props.dynamic_quantile || 'N/D';
  const tipoLabel = (typeof filtroClassificacao !== 'undefined' && filtroClassificacao.value === 'decil') ? 'Decil' : 'Quintil';

  /* SVGs com cores consistentes */
  const icons = {
    pop: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:18px; height:18px;"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>`,
    money: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:18px; height:18px; color:#103758;"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>`,
    sus: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:18px; height:18px;"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg>`,
    card: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:18px; height:18px;"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect></svg>`,
    rank: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:18px; height:18px;"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline></svg>`
  };

  /* Frase de Sintese (Logica de cores mantida) */
  let summaryHTML = '';
  if (props.percentil24_n != null) {
    const p = Number(props.percentil24_n);
    const isSuperior = p > 50;
    const statusClass = isSuperior ? 'text-status-superior' : 'text-status-inferior';
    const borderClass = isSuperior ? 'border-status-superior' : 'border-status-inferior';
    summaryHTML = `
      <div class="popup-badge-summary ${borderClass} ${statusClass}">
        Este município possui uma receita per capita <strong class="${statusClass}">${isSuperior ? 'superior a' : 'inferior a'} ${isSuperior ? Math.round(p) : (100 - Math.round(p))}%</strong> do país.
      </div>`;
  }

  const html = `
    <div class="popup-wrapper">
      <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3 pe-4">
        <div class="d-flex align-items-center gap-3">
          <h4 class="popup-title m-0">${props.name_muni_uf}</h4>
        </div>
        <span class="popup-badge-quintil me-3" style="background-color: ${corDaTag}">${quintilValue}º ${tipoLabel}</span>
      </div>
      
      <div class="popup-data-grid">
        <div class="popup-data-row">
          ${icons.pop}
          <div class="popup-info-content">
            <span class="popup-label">População</span>
            <span class="popup-value">${(+props.Populacao24).toLocaleString("pt-BR")}</span>
          </div>
        </div>

        <div class="popup-data-row">
          ${icons.money}
          <div class="popup-info-content">
            <span class="popup-label">Receita p/c</span>
            <span class="popup-value" style="color:#103758; font-size:18px; font-weight:900;">${(+props.rc_24_pc).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}</span>
          </div>
        </div>

        <div class="popup-data-row">
          ${icons.sus}
          <div class="popup-info-content">
            <span class="popup-label">Pop. SUS Dependente</span>
            <span class="popup-value">${props.sus_dependente || 'N/D'}%</span>
          </div>
        </div>

        <div class="popup-data-row">
          ${icons.card}
          <div class="popup-info-content">
            <span class="popup-label">Pop. CadÚnico</span>
            <span class="popup-value">${(+props.perc_pop_cadunico).toFixed(1)}%</span>
          </div>
        </div>

        <div class="popup-data-row">
          ${icons.rank}
          <div class="popup-info-content">
            <span class="popup-label">Percentil Nacional</span>
            <span class="popup-value">${props.percentil24 || 'N/D'}</span>
          </div>
        </div>
      </div>

      ${summaryHTML}

      <a href="/municipio/${props.cod_ibge}/" class="popup-btn-details" target="_blank">
        VER PAINEL COMPLETO <i class="fa-solid fa-chevron-right"></i>
      </a>
    </div>
  `;

/* Remove instâncias ativas do popup para evitar duplicação de elementos no DOM */
  /* --- No final da função abrirPopupDoMunicipioSelecionado --- */

  if (popupAtivo) {
      popupAtivo.remove();
  }

  popupAtivo = new mapboxgl.Popup({ 
      minWidth: '340px', 
      maxWidth: '420px', 
      className: 'ifem-premium-popup', 
      closeButton: true, 
      offset: 20,
      anchor: 'bottom',
      focusAfterOpen: false 
  })
    .setLngLat(coords)
    .setHTML(html)
    .addTo(map);

  // Adiciona a classe sempre (Desktop e Mobile)
  document.querySelector('.map-page').classList.add('popup-active');

  // Remove a classe quando o popup for fechado (pelo X ou clicando fora)
  popupAtivo.on('close', () => {
      document.querySelector('.map-page').classList.remove('popup-active');
  });
}

function hideBaseMunicipalityLayers() {
  const keywords = ['munic','muni','municip','cidade','cidades','cities','municipios','municipios-pontos'];
  const style = map.getStyle();
  if (!style || !style.layers) return;
  style.layers.forEach(layer => {
    const id = (layer.id||'').toLowerCase();
    const srcLayer = (layer['source-layer']||'').toLowerCase();
    const hay = id + ' ' + srcLayer;
    const match = keywords.some(k => hay.includes(k));
    const isOur = id.startsWith('populacao-circulos') || id.startsWith('municipio-labels');
    if (!isOur && match && (layer.type === 'circle' || layer.type === 'fill')) {
      try { map.setLayoutProperty(layer.id,'visibility','none'); } catch(_) {}
    }
  });
}

// ===================== Pintura (cores do mapa) =====================
function getMapPaintConfig(classification) {
  const prop = 'dynamic_quantile';
  switch (classification) {
    case 'decil':
      return ['match',['get',prop],
        1,'#a50026',2,'#d73027',3,'#f46d43',4,'#fdae61',5,'#fee08b',
        6,'#d9ef8b',7,'#a6d96a',8,'#66bd63',9,'#1a9850',10,'#006837',
        '#cccccc'];
    case 'natural':
      return ['step',['get','rc_24_pc'],
        '#d73027', 2500,'#fc8d59', 4000,'#fee08b', 6000,'#91cf60', 10000,'#1a9850'];
    case 'quintil':
    default:
      return ['match',['get',prop],
        1,'#d73027',2,'#fc8d59',3,'#fee08b',4,'#91cf60',5,'#1a9850','#cccccc'];
  }
}

// ===================== Legenda: Faixa Populacional (3 bolinhas) =====================
function buildSizeLegendSVGRow(config = [
  { label: '≤ 200 mil',   value: 120_000 },
  { label: '200–500 mil', value: 350_000 },
  { label: '> 500 mil',   value: 800_000 }
]) {
  const radiusFromPopulation = (pop) => {
    if (!Number.isFinite(pop) || pop <= 0) return 6;
    if (pop <= 100000)  return Math.max(6, 7 * (pop / 100000));
    if (pop <= 1000000) return 7 + (14-7) * ((pop-100000) / 900000);
    if (pop <= 10000000) return 14 + (28-14) * ((pop-1000000) / 9000000);
    return 28 + Math.log10(pop/10000000)*5;
  };

  const width = 240, height = 90;
  const startX = 50, gapX = 70, cy = 60;

  const radii = config.map(c => Math.max(6, radiusFromPopulation(c.value)));
  const parts = [
    `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">`,
    `<g fill="#fff" stroke="#111827" stroke-width="1" opacity="0.95">`
  ];

  radii.forEach((r, i) => {
    const cx = startX + i * gapX;
    parts.push(`<circle cx="${cx}" cy="${cy}" r="${r}"></circle>`);
    const ty = Math.max(14, cy - r - 8);
    parts.push(`<text x="${cx}" y="${ty}" font-size="12" fill="#374151" text-anchor="middle" dominant-baseline="central">${config[i].label}</text>`);
  });

  parts.push(`</g></svg>`);
  return parts.join('');
}

// ===================== Legenda: Cores (100% alinhada) =====================
function updateLegend(classification) {
  const legend = document.getElementById('legend');

  let header = 'Quintil';
  let items  = []; // {color, text}

  if (classification === 'decil') {
    header = 'Decil';
    items = [
      { color:'#a50026', text:'1º decil'  },
      { color:'#d73027', text:'2º decil'  },
      { color:'#f46d43', text:'3º decil'  },
      { color:'#fdae61', text:'4º decil'  },
      { color:'#fee08b', text:'5º decil'  },
      { color:'#d9ef8b', text:'6º decil'  },
      { color:'#a6d96a', text:'7º decil'  },
      { color:'#66bd63', text:'8º decil'  },
      { color:'#1a9850', text:'9º decil'  },
      { color:'#006837', text:'10º decil' }
    ];
  } else if (classification === 'natural') {
    header = 'Receita p/c (R$)';
    items = [
      { color:'#d73027', text:'< R$ 2.500' },
      { color:'#fc8d59', text:'R$ 2.500 – 4.000' },
      { color:'#fee08b', text:'R$ 4.000 – 6.000' },
      { color:'#91cf60', text:'R$ 6.000 – 10.000' },
      { color:'#1a9850', text:'> R$ 10.000' }
    ];
  } else {
    header = 'Quintil';
    items = [
      { color:'#d73027', text:'1º quintil' },
      { color:'#fc8d59', text:'2º quintil' },
      { color:'#fee08b', text:'3º quintil' },
      { color:'#91cf60', text:'4º quintil' },
      { color:'#1a9850', text:'5º quintil' }
    ];
  }

  const listHTML = `
    <h5>${header}</h5>
    <ul style="list-style:none;margin:.25rem 0 .5rem 0;padding:0;">
      ${items.map(it => `
        <li style="display:flex;align-items:center;gap:.5rem;margin:.15rem 0;font-size:.9rem;color:#444;">
          <span style="width:16px;height:12px;border-radius:3px;display:inline-block;border:1px solid rgba(0,0,0,.25);background-color:${it.color}"></span>
          <span>${it.text}</span>
        </li>`).join('')}
    </ul>
    <h6 class="legend-subtitle" style="margin-top:.5rem;border-top:1px solid #e5e7eb;padding-top:.5rem;">Faixa Populacional</h6>
    <div id="size-legend" class="size-legend"></div>
  `;

  legend.innerHTML = listHTML;
  legend.querySelector('#size-legend').innerHTML = buildSizeLegendSVGRow([
    { label: '≤ 200 mil',   value: 120_000 },
    { label: '200–500 mil', value: 350_000 },
    { label: '> 500 mil',   value: 800_000 }
  ]);
}

// ===================== Classificação (cores + subfiltro) =====================
function atualizarClassificacao() {
  const classificacao = filtroClassificacao.value;

  const novaCor = getMapPaintConfig(classificacao);
  map.setPaintProperty('populacao-circulos', 'circle-color', novaCor);
  updateLegend(classificacao);

  const subgrupoLabel  = document.querySelector('label[for="filtro-subgrupo"]');
  const subgrupoSelect = document.getElementById('filtro-subgrupo');
  subgrupoSelect.innerHTML = '<option value="todos">Todos</option>';

  switch (classificacao) {
    case 'decil':
      subgrupoLabel.textContent = 'Decil:';
      ['1','2','3','4','5','6','7','8','9','10'].forEach(v => subgrupoSelect.add(new Option(`${v}º decil`, v)));
      break;
    case 'natural':
      subgrupoLabel.textContent = 'Faixa de Receita:';
      const naturalOptions = {
        'Menos de R$ 2.500': '0-2500',
        'R$ 2.500 a 4.000': '2500-4000',
        'R$ 4.000 a 6.000': '4000-6000',
        'R$ 6.000 a 10.000': '6000-10000',
        'Acima de R$ 10.000': '10000-999999'
      };
      Object.entries(naturalOptions).forEach(([txt,val]) => subgrupoSelect.add(new Option(txt, val)));
      break;
    case 'quintil':
    default:
      subgrupoLabel.textContent = 'Quintil:';
      ['1','2','3','4','5'].forEach(v => subgrupoSelect.add(new Option(`${v}º quintil`, v)));
      break;
  }

  scheduleAtualizarMapa();
}

// ===================== Listeners =====================
document.getElementById('btn-limpar-filtros').addEventListener('click', async () => {
  filtroRegiao.value = 'todos';
  filtroRm.value = 'todos';
  filtroUf.value = 'todos';
  filtroMunicipio.value = 'todos';
  filtroPorte.value = 'todos';
  filtroSubgrupo.value = 'todos';
  filtroClassificacao.value = 'quintil';
  filtroModoCalculo.value = 'total';
  map.flyTo({ center: DEFAULT_VIEW.center, zoom: DEFAULT_VIEW.zoom, speed: 0.8, curve: 1.3 });
  await updateDependentFilters();
  atualizarClassificacao();
  if (popupAtivo) {
  popupAtivo.remove();
  popupAtivo = null;
}
});

[filtroRegiao, filtroUf, filtroRm, filtroMunicipio, filtroPorte, filtroSubgrupo]
  .forEach(sel => sel.addEventListener('change', async () => {
    
    if (sel === filtroMunicipio && filtroMunicipio.value === 'todos' && popupAtivo) {
      popupAtivo.remove();
      popupAtivo = null;
    }

    /* Se a mudanca nao for no municipio ou subgrupo, refaz a cascata antes de atualizar o mapa */
    if (sel !== filtroMunicipio && sel !== filtroSubgrupo) {
      await updateDependentFilters();
    }

    scheduleAtualizarMapa();
  }));


filtroModoCalculo.addEventListener('change', atualizarClassificacao);
filtroClassificacao.addEventListener('change', atualizarClassificacao);

map.on("mouseenter", "populacao-circulos", () => { map.getCanvas().style.cursor = "pointer"; });
map.on("mouseleave", "populacao-circulos", () => { map.getCanvas().style.cursor = ""; });

// ===================== Download CSV =====================
async function downloadTableData() {
  const apiUrl = buildApiUrl('/api/dados-municipios/', {
    regiao: filtroRegiao.value,
    uf: filtroUf.value,
    municipio: filtroMunicipio.value,
    porte: filtroPorte.value,
    subgrupo: filtroSubgrupo.value,
    rm: filtroRm.value,
    classification: filtroClassificacao.value,
    calculation_mode: filtroModoCalculo.value
  });

  try {
    const response = await fetch(apiUrl);
    const geojsonData = await response.json();
    const features = geojsonData.features || [];

    if (!features.length) { alert("Não há dados de municípios para baixar com os filtros atuais."); return; }

    const columns = [
      { header:"Município", property:"name_muni_uf" },
      { header:"População 2024", property:"Populacao24" },
      { header:"Receita Per Capita 2024", property:"rc_24_pc" },
      { header:"Quantil Dinâmico", property:"dynamic_quantile" },
      { header:"Quintil Pré-Calculado", property:"quintil24_pre_calculado" },
      { header:"Decil Pré-Calculado", property:"decil24_pre_calculado" },
      { header:"Percentil Nacional", property:"percentil24" },
      { header:"Percentil N", property:"percentil24_n" },
      { header:"Cód. IBGE", property:"cod_ibge" }
    ];

    let csvContent = columns.map(c => `"${c.header}"`).join(";") + "\n";
    features.forEach(f => {
      const row = columns.map(c => {
        let v = f.properties[c.property];
        if (v === null || v === undefined) v = "N/D";
        if (typeof v === 'number') v = String(v).replace(".", ",");
        return `"${v}"`;
      }).join(";");
      csvContent += row + "\n";
    });

    const blob = new Blob(["\uFEFF" + csvContent], { type:"text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "dados_municipios_filtrados.csv";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch (err) {
    console.error("Erro ao baixar dados da tabela:", err);
    alert("Ocorreu um erro ao tentar baixar os dados. Por favor, tente novamente.");
  }
}
document.getElementById('download-table-btn').addEventListener('click', downloadTableData);

// ======== PRINT DO MAPA =========
document.getElementById("btn-screenshot").addEventListener("click", async () => {

    await new Promise(r => requestAnimationFrame(r));

    const mapCanvas = map.getCanvas();
    const mapW = mapCanvas.width;
    const mapH = mapCanvas.height;

    // ===============================
    // 1) DEFINIR TAMANHO FIXO DO PRINT
    // ===============================
    const FINAL_WIDTH = 2400;
    const scaleFactor = FINAL_WIDTH / mapW;
    const FINAL_MAP_H = mapH * scaleFactor;

    const extraTop = 180;
    const extraBottom = 80;

    const FINAL_HEIGHT = extraTop + FINAL_MAP_H + extraBottom;

    const finalCanvas = document.createElement("canvas");
    finalCanvas.width = FINAL_WIDTH;
    finalCanvas.height = FINAL_HEIGHT;
    const ctx = finalCanvas.getContext("2d");

    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, FINAL_WIDTH, FINAL_HEIGHT);

    // ===============================
    // 2) LOGOS
    // ===============================
    async function loadImg(url) {
        return new Promise(resolve => {
            const i = new Image();
            i.crossOrigin = "anonymous";
            i.onload = () => resolve(i);
            i.onerror = () => resolve(null);
            i.src = url;
        });
    }

    const logo1 = await loadImg(window.LOGO_IFEM_URL);
    if (logo1) ctx.drawImage(logo1, 20, 20, 300, 100);

    const logo2 = await loadImg(window.LOGO_FNP_URL);
    if (logo2) ctx.drawImage(logo2, FINAL_WIDTH - 330, 20, 310, 100);



    // ===============================
    // 3) FILTROS EM LINHA
    // ===============================
    const headerY = 150;

    function boldIfNotAll(nome, valor) {
        if (!valor || valor.toLowerCase() === "todos" || valor.toLowerCase() === "todas") {
            return `${nome}: ${valor}`;
        }
        return `${nome}: **${valor}**`;
    }

    const filtros = [
        boldIfNotAll("Faixa Populacional", document.getElementById("filtro-porte").value),
        boldIfNotAll("Região Metropolitana", document.getElementById("filtro-rm").value),
        boldIfNotAll("Região", document.getElementById("filtro-regiao").value),
        boldIfNotAll("UF", document.getElementById("filtro-uf").value),
        boldIfNotAll("Município", document.getElementById("filtro-municipio").value)
    ];

    ctx.font = "24px Arial";
    ctx.fillStyle = "#333";

    let x = 20;
    const sep = "   |   ";

    for (const f of filtros) {
        const parts = f.split("**");
        ctx.fillText(parts[0], x, headerY);

        let offset = ctx.measureText(parts[0]).width;

        if (parts.length > 1) {
            ctx.font = "bold 24px Arial";
            ctx.fillText(parts[1], x + offset, headerY);
            offset += ctx.measureText(parts[1]).width;
            ctx.font = "24px Arial";
        }

        x += offset + ctx.measureText(sep).width;
    }

    // ===============================
    // 4) MAPA (ESCALADO)
    // ===============================
    const imgMap = new Image();
    imgMap.src = mapCanvas.toDataURL("image/png");
    await imgMap.decode();

    ctx.drawImage(
        imgMap,
        0,
        0,
        mapW,
        mapH,
        0,
        extraTop,
        FINAL_WIDTH,
        FINAL_MAP_H
    );

    // ===============================
    // 5) LEGENDA AUTOMÁTICA 
    // ===============================
    const legendDOM =
        document.querySelector(".legend-container") ||
        document.querySelector("#legend") ||
        document.querySelector(".map-legend");

    if (legendDOM) {

        const legendCanvas = await html2canvas(legendDOM, {
            backgroundColor: "#ffffff",
            scale: 2
        });

        const legendImg = new Image();
        legendImg.src = legendCanvas.toDataURL("image/png");
        await legendImg.decode();


        const originalW = legendCanvas.width;
        const originalH = legendCanvas.height;

        const scale = 1.05;

        let legendW = originalW * scale;
        let legendH = originalH * scale;

        // Limite seguro (máx 33% da largura final)
        const maxWidth = FINAL_WIDTH * 0.33;
        if (legendW > maxWidth) {
            const factor = maxWidth / legendW;
            legendW *= factor;
            legendH *= factor;
        }

        // Posição canto inferior direito
        const margin = 40;
        const cardX = FINAL_WIDTH - legendW - margin;
        const cardY = extraTop + FINAL_MAP_H - legendH - margin;

        // Sombra
        ctx.fillStyle = "rgba(0,0,0,0.15)";
        ctx.fillRect(cardX + 4, cardY + 4, legendW, legendH);

        // Card
        ctx.fillStyle = "#FFFFFF";
        ctx.strokeStyle = "rgba(0,0,0,0.18)";
        ctx.lineWidth = 3;
        ctx.roundRect(cardX, cardY, legendW, legendH, 20);
        ctx.fill();
        ctx.stroke();

        // Conteúdo da legenda
        ctx.drawImage(legendImg, cardX + 20, cardY + 20, legendW - 40, legendH - 40);
    }


    // ===============================
    // 6) RODAPÉ
    // ===============================
    ctx.font = "28px Arial";
    ctx.fillStyle = "#777";
    ctx.fillText(
        "Fonte: Mapbox | OpenStreetMap | FNP – Frente Nacional de Prefeitas e Prefeitos",
        20,
        FINAL_HEIGHT - 30
    );

    // ===============================
    // 7) DOWNLOAD
    // ===============================
    const a = document.createElement("a");
    a.download = "mapa_ifem.png";
    a.href = finalCanvas.toDataURL("image/png");
    a.click();
});
